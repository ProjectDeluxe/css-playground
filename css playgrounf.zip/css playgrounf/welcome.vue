// Plantilla para componentes .vue
// Tiene solo 3 etiquetas principales: template, script y style

// En template va el pedazo de código que queremos meter después en el html cuando necesitemos usarlo. Lo llamamos
desde el .vue principal (que es el que rejunta todos los componentes) y ese lo manda al html.
// Template solo puede tener un unico hijo, asi que todo el codigo que tengan que hacer va dentro de ese hijo.

// En script va el export para mandar el componente y todo lo de la instacia de vue que usamos antes (data, methods y demas)

// En style va el css nomás. Tiene el atributo scoped para indicarle que el estilo que estemos aplicando se usa 
solo para este componente y no para todos. Si dejamos style solo, si modifico el tamaño de algun texto de este
componente, se va a aplicar a los textos que cumplan con la misma etiqueta.


<template>
    <div class="fullscreen">
        <h1>{{data.intro.title}}</h1>

    </div>
</template>


<script>
    export default {
        props: ["data"]
        
    }
    var i = 0, text;
    text = data.intro.title

    function typing(){
        if(i<text.length){
            document.getElementById("text").innerHTML += text.charAt(i);
            i++;
            setTimeout(typing,50);
        }
    }
    typing()
</script>


<style scoped>
    *{
        background: #1089FF;
        margin: 0;
        font-family: 'Righteous' ;
    }
    .fullscreen{
        width: 100vw;
        height: 100vh;
    }

</style>